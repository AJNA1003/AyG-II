# AyG-II
1. Se creo el README como archivo inicial
2. Se subio desde la pagina de github.com el archivo trabajado en Laboratorio 1 para su uso en linea
3. Mis contribuidores se añadieron al repositorio
4. Jesus empezó con el manual de usuario
5. Jazer hizo una pull request para subir la Gestión de errores
6. Jesus subio el manual de usuario a github y resolvio algunos errores 
7. Se realizó un correción por parte de Jazer
8. Se realizó una correcion con respecto a un error en el codigo
9. Santiago hizo una pull request para aparecer en el repositorio
10. Santiago esta subiendo su archivo.....
